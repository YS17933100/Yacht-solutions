import { useState, useRef, useCallback } from "react";

// ── DONNÉES DÉMO ──────────────────────────────────
const COLORS = ["#1E4D8C","#2D6A4F","#7C3AED","#B45309","#BE185D","#0E7490","#DC2626"];
const TECHS = ["Marc D.","Julie R.","Pierre L.","Sofia M.","Théodore","Pauline"];
const MN = ["Jan","Fév","Mar","Avr","Mai","Jun","Jul","Aoû","Sep","Oct","Nov","Déc"];
const QC4 = [{id:"r",l:"Raccordement"},{id:"e",l:"Essai"},{id:"i",l:"Identification"},{id:"p",l:"Propreté"}];
const QC3 = [{id:"f",l:"Finition"},{id:"lg",l:"Lagoon+"},{id:"c",l:"Conformité"}];
const BOIS = ["CL Bois Solutions","Bonaventura Yachting","Teck Inox","Métamorchose"];
const qcSteps = p => BOIS.includes(p) ? QC3 : QC4;

// ── HELPERS DATE ──────────────────────────────────
const iso = d => (d instanceof Date ? d : new Date(d)).toISOString().slice(0,10);
const pd = s => s ? new Date(s+"T00:00:00") : null;
const addD = (s,n) => { const r=pd(s); r.setDate(r.getDate()+n); return r; };
const fmt = s => s ? pd(s).toLocaleDateString("fr-FR",{day:"numeric",month:"short"}) : "—";
const fmtL = s => s ? pd(s).toLocaleDateString("fr-FR",{weekday:"short",day:"numeric",month:"short"}) : "—";
const dim = (y,m) => new Date(y,m+1,0).getDate();
const workDays = (s,e) => { const d=[],end=pd(e); let c=pd(s); while(c<=end){const w=c.getDay();if(w&&w!==6)d.push(iso(c));c=addD(iso(c),1);} return d; };

const buildSched = (arts,s,e,hpd=5) => {
  const wd=workDays(s,e); if(!wd.length) return {};
  const idx={},rem={},sched={};
  arts.filter(a=>a.tech&&a.h>0).forEach(a=>{
    const t=a.tech;
    if(idx[t]===undefined){idx[t]=0;rem[t]=hpd;}
    sched[a.id]=[];let r=a.h;
    while(r>0&&idx[t]<wd.length){const av=Math.min(rem[t],r);if(av>0){sched[a.id].push({date:wd[idx[t]],hours:av});r-=av;rem[t]-=av;if(rem[t]<=0){idx[t]++;rem[t]=hpd;}}else{idx[t]++;rem[t]=hpd;}}
  });
  return sched;
};

const A0 = [
  {id:"t1",num:"15268",nom:"Installation Starlink",prest:"Yacht Solutions",h:10,tech:"Théodore",done:false,photos:[],mt:[{id:1,l:"Pose antenne",ok:false,ph:null},{id:2,l:"Tirage câble",ok:false,ph:null},{id:3,l:"Configuration",ok:false,ph:null}]},
  {id:"t2",num:"15651",nom:"Prise 220V",prest:"Yacht Solutions",h:8,tech:"Pauline",done:false,photos:[],mt:[{id:4,l:"Perçage tableau",ok:false,ph:null},{id:5,l:"Raccordement",ok:false,ph:null}]},
  {id:"t3",num:"",nom:"Écran Axiom 12",prest:"Yacht Solutions",h:4,tech:"Pauline",done:false,photos:[],mt:[{id:6,l:"Montage support",ok:false,ph:null},{id:7,l:"Connexion NMEA",ok:false,ph:null}]},
];
const BOATS0 = [
  {id:1,name:"L60 #16",model:"Lagoon 60",owner:"Client A",color:"#1E4D8C",s:"2025-08-08",e:"2025-08-16",dep:"2025-08-18",hpd:5,sh:"08:00",annots:[{id:1,date:"2025-08-10",txt:"Mise à l'eau"},{id:2,date:"2025-08-14",txt:"Mâtage"}],docs:[],arts:A0,sched:buildSched(A0,"2025-08-08","2025-08-16",5),qc:{}},
  {id:2,name:"Horizon III",model:"Bavaria 46",owner:"J. Dupont",color:"#2D6A4F",s:"2025-06-07",e:"2025-07-07",dep:"2025-07-10",hpd:5,sh:"07:30",annots:[{id:1,date:"2025-06-25",txt:"Mâtage"}],docs:[],
    arts:[{id:"b1",num:"14974",nom:"Protection chaîne",prest:"Yacht Solutions",h:3,tech:"Marc D.",done:true,photos:[],mt:[{id:10,l:"Démontage",ok:true,ph:null},{id:11,l:"Pose",ok:true,ph:null}]},{id:"b2",num:"5863",nom:"Sortie eau flybridge",prest:"Yacht Solutions",h:4,tech:"Julie R.",done:false,photos:[],mt:[{id:12,l:"Perçage",ok:true,ph:null},{id:13,l:"Raccordement",ok:false,ph:null}]}],
    sched:{},qc:{}}
];

// ── ICÔNES ────────────────────────────────────────
const IC = {
  back: "←", close: "✕", plus: "+", cam: "📷", pin: "📍",
  check: "✓", drag: "⠿", pdf: "📄", boat: "⛵", user: "👤",
};

// ── PRIMITIVES UI ─────────────────────────────────
const S = {
  root:{display:"flex",flexDirection:"column",minHeight:"100vh",background:"#0D1B2A",fontFamily:"system-ui,sans-serif",color:"#E2E8F0",maxWidth:"430px",margin:"0 auto"},
  hdr:{background:"#0A1520",borderBottom:"1px solid #1A2D42",position:"sticky",top:0,zIndex:10,padding:"10px 14px",display:"flex",alignItems:"center",gap:"10px"},
  card:{background:"#0A1520",border:"1px solid #1A2D42",borderRadius:"10px"},
  or:{background:"#F4821E",color:"#fff",border:"none",padding:"10px 16px",borderRadius:"9px",fontSize:"14px",fontWeight:"600",cursor:"pointer",fontFamily:"inherit",display:"flex",alignItems:"center",gap:"6px",justifyContent:"center"},
  gh:{background:"transparent",color:"#CBD5E0",border:"1px solid #1A2D42",padding:"9px 14px",borderRadius:"9px",fontSize:"13px",cursor:"pointer",fontFamily:"inherit",display:"flex",alignItems:"center",gap:"6px",justifyContent:"center"},
  ib:{background:"transparent",border:"none",color:"#CBD5E0",cursor:"pointer",padding:"4px",fontSize:"18px"},
  ov:{position:"fixed",inset:0,background:"rgba(0,0,0,.8)",zIndex:100,display:"flex",alignItems:"flex-end"},
  sh:{background:"#0F1E2E",borderRadius:"20px 20px 0 0",width:"100%",maxHeight:"90vh",border:"1px solid #1A2D42",borderBottom:"none",display:"flex",flexDirection:"column"},
};

function Inp({value,onChange,placeholder,type="text"}){
  return <input type={type} value={value} onChange={e=>onChange(e.target.value)} placeholder={placeholder}
    style={{width:"100%",background:"#0D1B2A",border:"1px solid #253650",borderRadius:"8px",padding:"9px 11px",color:"#E2E8F0",fontSize:"14px",boxSizing:"border-box",outline:"none",fontFamily:"inherit"}}/>;
}
function Sel({value,onChange,opts}){
  return <select value={value} onChange={e=>onChange(e.target.value)}
    style={{width:"100%",background:"#0D1B2A",border:"1px solid #253650",borderRadius:"8px",padding:"9px 11px",color:"#E2E8F0",fontSize:"14px",boxSizing:"border-box",outline:"none",fontFamily:"inherit"}}>
    {opts.map(o=><option key={o.v} value={o.v}>{o.l}</option>)}
  </select>;
}
function Lbl({label,children}){
  return <div style={{marginBottom:"10px"}}>
    {label&&<div style={{fontSize:"11px",color:"#718096",textTransform:"uppercase",fontWeight:"600",marginBottom:"4px"}}>{label}</div>}
    {children}
  </div>;
}
function Sheet({title,onClose,children}){
  return <div style={S.ov} onClick={onClose}>
    <div style={S.sh} onClick={e=>e.stopPropagation()}>
      <div style={{width:"36px",height:"4px",background:"#253650",borderRadius:"2px",margin:"10px auto 0"}}/>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",padding:"12px 18px 10px",borderBottom:"1px solid #1A2D42"}}>
        <span style={{fontSize:"16px",fontWeight:"700"}}>{title}</span>
        <button style={S.ib} onClick={onClose}>{IC.close}</button>
      </div>
      <div style={{padding:"14px 18px 32px",overflowY:"auto",flex:1}}>{children}</div>
    </div>
  </div>;
}
function Ring({pct,color,size=38}){
  const r=(size-6)/2,c=2*Math.PI*r;
  return <svg width={size} height={size} style={{flexShrink:0}}>
    <circle cx={size/2} cy={size/2} r={r} fill="none" stroke="#1A2332" strokeWidth="3"/>
    <circle cx={size/2} cy={size/2} r={r} fill="none" stroke={color} strokeWidth="3" strokeDasharray={`${(pct/100)*c} ${c}`} strokeLinecap="round" transform={`rotate(-90 ${size/2} ${size/2})`}/>
    <text x={size/2} y={size/2+4} textAnchor="middle" fontSize="9" fill="#E2E8F0" fontWeight="700">{pct}%</text>
  </svg>;
}
function Notif({n}){
  return n?<div style={{position:"fixed",top:"50%",left:"50%",transform:"translate(-50%,-50%)",background:n.err?"#EF4444":"#22C55E",color:"#fff",padding:"12px 24px",borderRadius:"12px",fontWeight:"600",fontSize:"14px",zIndex:500,maxWidth:"280px",textAlign:"center",pointerEvents:"none"}}>{n.msg}</div>:null;
}
function useNotif(){
  const [n,setN]=useState(null);
  const show=useCallback((msg,err=false)=>{setN({msg,err});setTimeout(()=>setN(null),2600);},[]);
  return [n,show];
}

// ── FAB ───────────────────────────────────────────
function FAB({onBoat,onImport}){
  const [open,setOpen]=useState(false);
  return <>
    {open&&<div style={{position:"fixed",inset:0,zIndex:49}} onClick={()=>setOpen(false)}/>}
    <div style={{position:"fixed",bottom:"20px",right:"16px",zIndex:50,display:"flex",flexDirection:"column",alignItems:"flex-end",gap:"10px"}}>
      {open&&<>
        <FabRow label="Nouveau bateau" onClick={()=>{setOpen(false);onBoat();}}/>
        <FabRow label="Importer fichier" onClick={()=>{setOpen(false);onImport();}}/>
      </>}
      <button onClick={()=>setOpen(o=>!o)} style={{...S.or,width:"52px",height:"52px",borderRadius:"26px",fontSize:"24px",boxShadow:"0 4px 20px rgba(244,130,30,.5)",transform:open?"rotate(45deg)":"none",transition:"transform .2s"}}>{IC.plus}</button>
    </div>
  </>;
}
function FabRow({label,onClick}){
  return <div style={{display:"flex",alignItems:"center",gap:"9px"}}>
    <span style={{background:"#0A1520",color:"#E2E8F0",padding:"5px 11px",borderRadius:"8px",fontSize:"13px",fontWeight:"600",border:"1px solid #1A2D42"}}>{label}</span>
    <button onClick={onClick} style={{...S.or,width:"40px",height:"40px",borderRadius:"20px",fontSize:"18px",padding:"0"}}>{IC.plus}</button>
  </div>;
}

// ── GANTT ─────────────────────────────────────────
function Gantt({boats,onBoat,addBoat}){
  const now=new Date();
  const [yr,setYr]=useState(now.getFullYear());
  const [mo,setMo]=useState(now.getMonth());
  const d=dim(yr,mo), days=Array.from({length:d},(_,i)=>i+1);
  const active=boats.filter(b=>{if(!b.s)return false;const s=pd(b.s),e=b.e?pd(b.e):s;return s<=new Date(yr,mo,d)&&e>=new Date(yr,mo,1);});
  const pm=()=>{if(mo===0){setMo(11);setYr(y=>y-1);}else setMo(m=>m-1);};
  const nm=()=>{if(mo===11){setMo(0);setYr(y=>y+1);}else setMo(m=>m+1);};
  return <div style={{padding:"14px",paddingBottom:"90px"}}>
    <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:"10px"}}>
      <div><div style={{fontSize:"17px",fontWeight:"700"}}>Gantt</div><div style={{fontSize:"11px",color:"#718096"}}>{active.length} actif{active.length!==1?"s":""}</div></div>
      <div style={{display:"flex",alignItems:"center",gap:"6px"}}>
        <button style={{...S.gh,padding:"6px 10px"}} onClick={pm}>‹</button>
        <div style={{textAlign:"center",minWidth:"80px"}}><div style={{fontSize:"13px",fontWeight:"700"}}>{MN[mo]}</div><div style={{fontSize:"11px",color:"#718096"}}>{yr}</div></div>
        <button style={{...S.gh,padding:"6px 10px"}} onClick={nm}>›</button>
      </div>
    </div>
    <div style={{display:"flex",gap:"4px",overflowX:"auto",paddingBottom:"8px",marginBottom:"10px",scrollbarWidth:"none"}}>
      {MN.map((m,i)=><button key={i} onClick={()=>setMo(i)} style={{padding:"3px 8px",borderRadius:"14px",border:"1px solid #1A2D42",background:mo===i?"#F4821E":"transparent",color:mo===i?"#fff":"#718096",cursor:"pointer",fontSize:"11px",fontFamily:"inherit",whiteSpace:"nowrap"}}>{m}</button>)}
    </div>
    {active.length===0&&<div style={{textAlign:"center",padding:"50px 0",color:"#4A5568"}}><div style={{fontSize:"36px",marginBottom:"10px"}}>⛵</div><div style={{marginBottom:"14px"}}>Aucun bateau ce mois</div><button style={{...S.or}} onClick={addBoat}>{IC.plus} Nouveau bateau</button></div>}
    {active.length>0&&<div style={{...S.card,overflow:"hidden",marginBottom:"10px"}}>
      <div style={{display:"flex",borderBottom:"2px solid #1A2D42"}}>
        <div style={{width:"80px",flexShrink:0,padding:"5px 7px",fontSize:"10px",color:"#4A5568",fontWeight:"700",borderRight:"1px solid #1A2D42"}}>BATEAU</div>
        <div style={{flex:1,display:"flex",overflowX:"hidden"}}>
          {days.map(d=>{const dw=new Date(yr,mo,d).getDay(),wk=dw===0||dw===6,td=iso(new Date(yr,mo,d))===iso(new Date());
            return <div key={d} style={{flex:1,padding:"2px 0",textAlign:"center",background:td?"#F4821E22":wk?"#1A2D4233":"transparent",borderLeft:"1px solid #1A2D4222"}}>
              <div style={{fontSize:"8px",color:td?"#F4821E":"#4A5568"}}>{"DLMMJVS"[dw]}</div>
              <div style={{fontSize:"9px",fontWeight:td?"800":"500",color:td?"#F4821E":"#718096"}}>{d}</div>
            </div>;})}
        </div>
      </div>
      {active.map(b=>{
        const ann=b.annots.filter(a=>{const d=pd(a.date);return d&&d.getMonth()===mo&&d.getFullYear()===yr;});
        const dep=b.dep?pd(b.dep):null;const j2=b.dep?iso(addD(b.dep,-2)):null;
        return <div key={b.id} style={{borderTop:"1px solid #1A2D4233",cursor:"pointer"}} onClick={()=>onBoat(b)}>
          <div style={{display:"flex",minHeight:"40px"}}>
            <div style={{width:"80px",flexShrink:0,padding:"4px 7px",borderRight:"1px solid #1A2D42",display:"flex",flexDirection:"column",justifyContent:"center"}}>
              <div style={{fontSize:"11px",fontWeight:"700",overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{b.name}</div>
              <div style={{fontSize:"9px",color:"#4A5568",overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{b.model}</div>
            </div>
            <div style={{flex:1,display:"flex"}}>
              {days.map(d=>{
                const cd=iso(new Date(yr,mo,d));
                const inW=b.s&&b.e&&cd>=b.s&&cd<=b.e;
                const isDep=dep&&cd===iso(dep),isJ2=j2&&cd===j2;
                const dw=new Date(yr,mo,d).getDay(),wk=dw===0||dw===6;
                const an=ann.find(a=>pd(a.date).getDate()===d);
                return <div key={d} style={{flex:1,position:"relative",background:isDep?"#F4821E33":isJ2?"#F59E0B22":inW&&!wk?b.color+"33":wk?"#1A2D4233":"transparent",borderLeft:"1px solid #1A2D4211"}}>
                  {inW&&!wk&&<div style={{position:"absolute",left:0,right:0,height:"3px",background:b.color,top:"50%",transform:"translateY(-50%)"}}/>}
                  {an&&<div style={{position:"absolute",bottom:"2px",width:"5px",height:"5px",borderRadius:"50%",background:"#F4821E",left:"50%",transform:"translateX(-50%)"}}/>}
                  {isDep&&<div style={{position:"absolute",top:"1px",left:"50%",transform:"translateX(-50%)",fontSize:"9px"}}>⚓</div>}
                  {isJ2&&<div style={{position:"absolute",top:"1px",left:"50%",transform:"translateX(-50%)",fontSize:"7px",color:"#F59E0B",fontWeight:"700"}}>J-2</div>}
                </div>;})}
            </div>
          </div>
          {ann.length>0&&<div style={{display:"flex",gap:"8px",padding:"2px 6px 3px 86px",flexWrap:"wrap"}}>
            {ann.map(a=><span key={a.id} style={{fontSize:"9px",color:"#F4821E"}}>{IC.pin}{a.txt}</span>)}
          </div>}
        </div>;
      })}
    </div>}
    <div style={{fontSize:"10px",color:"#4A5568",textAlign:"center"}}>⚓ Départ · J-2 Deadline · ● Annotation · Tapez un bateau</div>
  </div>;
}

// ── FICHE BATEAU ──────────────────────────────────
function BoatPage({boat:b0,boats,setBoats,back,show}){
  const [tab,setTab]=useState("info");
  const b=boats.find(x=>x.id===b0.id)||b0;
  const up=useCallback(fn=>setBoats(p=>p.map(x=>x.id===b0.id?fn(x):x)),[b0.id,setBoats]);
  const [taskId,setTaskId]=useState(null);
  const [edit,setEdit]=useState(false);
  const [df,setDf]=useState({s:b.s||"",e:b.e||"",dep:b.dep||"",sh:b.sh||"08:00",hpd:String(b.hpd||5)});
  const [aTxt,setATxt]=useState(""),aDate=useState(b.s||"")[0],setADate=useState(b.s||"")[1];
  const [aD,setAD]=useState(b.s||"");
  const [showA,setShowA]=useState(false);
  const docRef=useRef();
  const fd=(k,v)=>setDf(p=>({...p,[k]:v}));

  if(taskId){const art=b.arts.find(a=>a.id===taskId);if(art)return <TaskPage art={art} boat={b} up={up} back={()=>setTaskId(null)} show={show}/>;}

  const totalH=b.arts.reduce((s,a)=>s+(a.h||0),0);
  const dur=b.s&&b.e?Math.round((pd(b.e)-pd(b.s))/86400000):0;

  return <div style={{...S.root,position:"fixed",inset:0,zIndex:80,display:"flex",flexDirection:"column"}}>
    <div style={S.hdr}>
      <button style={S.ib} onClick={back}>{IC.back}</button>
      <div style={{flex:1}}><div style={{fontSize:"10px",color:b.color,textTransform:"uppercase",fontWeight:"700"}}>{b.model}</div><div style={{fontSize:"16px",fontWeight:"800"}}>{b.name}</div></div>
      <div style={{width:"10px",height:"10px",borderRadius:"2px",background:b.color}}/>
    </div>
    <div style={{display:"flex",background:"#0A1520",borderBottom:"1px solid #1A2D42"}}>
      {[{id:"info",l:"Infos"},{id:"arts",l:`Articles (${b.arts.length})`},{id:"plan",l:"Planning"}].map(t=>(
        <button key={t.id} onClick={()=>setTab(t.id)} style={{flex:1,padding:"9px 0",background:"transparent",border:"none",borderBottom:tab===t.id?"2px solid #F4821E":"2px solid transparent",color:tab===t.id?"#F4821E":"#718096",cursor:"pointer",fontSize:"12px",fontWeight:tab===t.id?"700":"400",fontFamily:"inherit"}}>{t.l}</button>
      ))}
    </div>
    <div style={{flex:1,overflowY:"auto",padding:"14px",paddingBottom:"90px"}}>

    {tab==="info"&&<>
      <div style={{...S.card,padding:"13px",marginBottom:"12px"}}>
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:"9px"}}>
          <span style={{fontWeight:"700",fontSize:"14px"}}>Dates</span>
          <button style={{...S.gh,padding:"4px 9px",fontSize:"11px"}} onClick={()=>setEdit(e=>!e)}>{edit?"Annuler":"Modifier"}</button>
        </div>
        {!edit?<>
          <div style={{display:"flex",gap:"14px",marginBottom:"7px",flexWrap:"wrap"}}>
            <div><div style={{fontSize:"9px",color:"#4A5568",textTransform:"uppercase"}}>Début</div><div style={{fontWeight:"600",fontSize:"13px"}}>{fmt(b.s)}</div></div>
            <div><div style={{fontSize:"9px",color:"#4A5568",textTransform:"uppercase"}}>Fin</div><div style={{fontWeight:"600",fontSize:"13px"}}>{fmt(b.e)}</div></div>
            <div><div style={{fontSize:"9px",color:"#4A5568",textTransform:"uppercase"}}>Durée</div><div style={{fontWeight:"600",color:"#F4821E",fontSize:"13px"}}>{dur}j</div></div>
          </div>
          {b.dep&&<div style={{display:"flex",alignItems:"center",gap:"8px",padding:"7px 10px",background:"#F4821E11",borderRadius:"8px",border:"1px solid #F4821E33"}}>
            <span style={{fontSize:"18px"}}>⚓</span>
            <div style={{flex:1}}><div style={{fontSize:"9px",color:"#F4821E",fontWeight:"700",textTransform:"uppercase"}}>Départ client</div><div style={{fontSize:"13px",fontWeight:"700",color:"#F4821E"}}>{fmt(b.dep)}</div></div>
            <div style={{textAlign:"right"}}><div style={{fontSize:"9px",color:"#F59E0B"}}>J-2</div><div style={{fontSize:"12px",fontWeight:"700",color:"#F59E0B"}}>{fmt(iso(addD(b.dep,-2)))}</div></div>
          </div>}
          <div style={{fontSize:"11px",color:"#718096",marginTop:"7px"}}>⏰ {b.sh||"08:00"} · {b.hpd||5}h/j · {totalH}h total</div>
        </>:<>
          <div style={{display:"flex",gap:"8px",marginBottom:"8px"}}><div style={{flex:1}}><Lbl label="Début"><Inp type="date" value={df.s} onChange={v=>fd("s",v)}/></Lbl></div><div style={{flex:1}}><Lbl label="Fin"><Inp type="date" value={df.e} onChange={v=>fd("e",v)}/></Lbl></div></div>
          <Lbl label="Départ client ⚓"><Inp type="date" value={df.dep} onChange={v=>fd("dep",v)}/></Lbl>
          <div style={{display:"flex",gap:"8px",marginBottom:"8px"}}><div style={{flex:1}}><Lbl label="Heure début"><Inp type="time" value={df.sh} onChange={v=>fd("sh",v)}/></Lbl></div><div style={{flex:1}}><Lbl label="H/jour"><Sel value={df.hpd} onChange={v=>fd("hpd",v)} opts={[3,4,5,6,7,8].map(n=>({v:String(n),l:`${n}h`}))}/></Lbl></div></div>
          <button style={{...S.or,width:"100%"}} onClick={()=>{up(x=>({...x,s:df.s,e:df.e,dep:df.dep,sh:df.sh,hpd:Number(df.hpd)}));setEdit(false);show("📅 Dates sauvegardées !");}}>Enregistrer</button>
        </>}
      </div>

      <div style={{...S.card,padding:"13px",marginBottom:"12px"}}>
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:"9px"}}>
          <span style={{fontWeight:"700",fontSize:"14px"}}>Annotations</span>
          <button style={{...S.or,padding:"4px 10px",fontSize:"11px"}} onClick={()=>setShowA(s=>!s)}>+</button>
        </div>
        {showA&&<div style={{background:"#0D1B2A",border:"1px solid #253650",borderRadius:"8px",padding:"10px",marginBottom:"10px"}}>
          <Lbl label="Date"><Inp type="date" value={aD} onChange={setAD}/></Lbl>
          <Lbl label="Texte"><Inp value={aTxt} onChange={setATxt} placeholder="ex : Mise à l'eau"/></Lbl>
          <button style={{...S.or,width:"100%"}} onClick={()=>{if(!aTxt.trim()||!aD)return;up(x=>({...x,annots:[...x.annots,{id:Date.now(),date:aD,txt:aTxt.trim()}]}));setATxt("");setShowA(false);show("📌 Annotation ajoutée !");}}>Ajouter</button>
        </div>}
        {b.annots.length===0&&<div style={{fontSize:"12px",color:"#4A5568"}}>Aucune annotation</div>}
        {[...b.annots].sort((a,c)=>a.date.localeCompare(c.date)).map(a=><div key={a.id} style={{display:"flex",alignItems:"center",gap:"8px",padding:"5px 0",borderTop:"1px solid #1A2D4233"}}>
          <span style={{color:"#F4821E",fontSize:"12px"}}>{IC.pin}</span>
          <div style={{flex:1}}><div style={{fontSize:"11px",color:"#718096"}}>{fmtL(a.date)}</div><div style={{fontSize:"13px",fontWeight:"600"}}>{a.txt}</div></div>
          <button style={{...S.ib,fontSize:"16px",color:"#4A5568"}} onClick={()=>up(x=>({...x,annots:x.annots.filter(z=>z.id!==a.id)}))}>×</button>
        </div>)}
      </div>

      <div style={{...S.card,padding:"13px",marginBottom:"12px"}}>
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:"9px"}}>
          <span style={{fontWeight:"700",fontSize:"14px"}}>Documents</span>
          <button style={{...S.or,padding:"4px 10px",fontSize:"11px"}} onClick={()=>docRef.current?.click()}>{IC.pdf} Ajouter</button>
        </div>
        <input type="file" accept=".pdf,image/*" ref={docRef} style={{display:"none"}} onChange={e=>{const f=e.target.files[0];if(!f)return;const url=URL.createObjectURL(f);up(x=>({...x,docs:[...x.docs,{id:Date.now(),name:f.name,url,date:new Date().toLocaleDateString("fr-FR")}]}));show("📄 Document ajouté !");e.target.value="";}}/>
        {(b.docs||[]).length===0&&<div style={{fontSize:"12px",color:"#4A5568"}}>Plans, modes opératoires, validations…</div>}
        {(b.docs||[]).map(d=><div key={d.id} style={{display:"flex",alignItems:"center",gap:"8px",padding:"5px 0",borderTop:"1px solid #1A2D4233"}}>
          <span>📄</span>
          <div style={{flex:1,overflow:"hidden"}}><div style={{fontSize:"12px",fontWeight:"600",overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{d.name}</div><div style={{fontSize:"10px",color:"#718096"}}>{d.date}</div></div>
          <a href={d.url} target="_blank" rel="noreferrer" style={{...S.gh,padding:"3px 8px",fontSize:"11px",textDecoration:"none"}}>Ouvrir</a>
          <button style={{...S.ib,color:"#4A5568",fontSize:"16px"}} onClick={()=>up(x=>({...x,docs:x.docs.filter(z=>z.id!==d.id)}))}>×</button>
        </div>)}
      </div>
    </>}

    {tab==="arts"&&<ArtsTab boat={b} up={up} setTaskId={setTaskId} show={show}/>}
    {tab==="plan"&&<PlanTab boat={b} up={up} show={show}/>}
    </div>
  </div>;
}

// ── ARTICLES TAB ──────────────────────────────────
function ArtsTab({boat:b,up,setTaskId,show}){
  const [extra,setExtra]=useState([]);
  const [newT,setNewT]=useState("");
  const [assign,setAssign]=useState(null);
  const [addArt,setAddArt]=useState(false);
  const allT=[...new Set([...TECHS,...b.arts.map(a=>a.tech).filter(Boolean),...extra])];
  const setTech=(id,t)=>{up(x=>({...x,arts:x.arts.map(a=>a.id===id?{...a,tech:t}:a)}));setAssign(null);show(`👤 Assigné à ${t}`);};
  const totalH=b.arts.reduce((s,a)=>s+(a.h||0),0);
  return <>
    <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:"10px"}}>
      <div style={{fontSize:"12px",color:"#718096"}}>{b.arts.length} articles · {totalH}h</div>
      <button style={{...S.or,padding:"6px 11px",fontSize:"12px"}} onClick={()=>setAddArt(true)}>+ Article</button>
    </div>
    <div style={{...S.card,padding:"11px",marginBottom:"12px"}}>
      <div style={{fontSize:"11px",color:"#718096",fontWeight:"700",textTransform:"uppercase",marginBottom:"7px"}}>Équipe</div>
      <div style={{display:"flex",gap:"5px",flexWrap:"wrap",marginBottom:"8px"}}>
        {allT.map(t=><span key={t} style={{padding:"3px 9px",background:"#253650",borderRadius:"20px",fontSize:"12px",color:"#CBD5E0"}}>{t}</span>)}
      </div>
      <div style={{display:"flex",gap:"6px"}}>
        <Inp value={newT} onChange={setNewT} placeholder="Ajouter un technicien…"/>
        <button style={{...S.or,padding:"8px 11px",flexShrink:0}} onClick={()=>{if(newT.trim()&&!allT.includes(newT.trim())){setExtra(p=>[...p,newT.trim()]);setNewT("");}}}>{IC.plus}</button>
      </div>
    </div>
    {b.arts.length===0&&<div style={{textAlign:"center",padding:"36px 0",color:"#4A5568"}}><div style={{fontSize:"28px",marginBottom:"8px"}}>📋</div><div>Aucun article</div></div>}
    {b.arts.map(a=>{
      const pct=a.mt.length?Math.round(a.mt.filter(m=>m.ok).length/a.mt.length*100):a.done?100:0;
      const isA=assign===a.id;
      return <div key={a.id} style={{...S.card,marginBottom:"9px",padding:"11px 12px"}}>
        <div style={{display:"flex",alignItems:"flex-start",gap:"10px",marginBottom:"8px"}}>
          <div style={{flex:1}}>
            {a.num&&<span style={{fontSize:"10px",color:"#4A5568",fontFamily:"monospace",marginRight:"4px"}}>#{a.num}</span>}
            <div style={{fontSize:"13px",fontWeight:"600",lineHeight:"1.3"}}>{a.nom}</div>
            <div style={{fontSize:"11px",color:"#718096",marginTop:"2px"}}>{a.prest}{a.h?` · ${a.h}h`:""}</div>
          </div>
          <Ring pct={pct} color={b.color} size={36}/>
        </div>
        {!isA?<div style={{display:"flex",alignItems:"center",gap:"8px",padding:"6px 0",borderTop:"1px solid #1A2D4233",borderBottom:"1px solid #1A2D4233",marginBottom:"8px"}}>
          <span style={{fontSize:"12px"}}>{IC.user}</span>
          <span style={{flex:1,fontSize:"12px",color:a.tech?"#E2E8F0":"#F59E0B",fontStyle:a.tech?"normal":"italic"}}>{a.tech||"⚠ Non assigné"}</span>
          <button style={{...S.or,padding:"4px 10px",fontSize:"11px"}} onClick={()=>setAssign(a.id)}>Assigner</button>
        </div>:<div style={{background:"#0D1B2A",border:"1px solid #F4821E",borderRadius:"8px",padding:"10px",marginBottom:"8px"}}>
          <div style={{fontSize:"11px",color:"#F4821E",fontWeight:"700",marginBottom:"7px"}}>Choisir le technicien :</div>
          <div style={{display:"flex",gap:"5px",flexWrap:"wrap",marginBottom:"7px"}}>
            {allT.map(t=><button key={t} onClick={()=>setTech(a.id,t)} style={{padding:"5px 10px",borderRadius:"8px",border:`1px solid ${a.tech===t?"#F4821E":"#253650"}`,background:a.tech===t?"#F4821E":"transparent",color:a.tech===t?"#fff":"#CBD5E0",cursor:"pointer",fontSize:"12px",fontFamily:"inherit"}}>{t}</button>)}
          </div>
          <button style={{fontSize:"11px",color:"#718096",background:"transparent",border:"none",cursor:"pointer",fontFamily:"inherit"}} onClick={()=>setAssign(null)}>Annuler</button>
        </div>}
        {a.mt.length>0&&<div style={{marginBottom:"8px"}}><div style={{height:"3px",background:"#1A2D42",borderRadius:"2px",overflow:"hidden",marginBottom:"3px"}}><div style={{height:"100%",width:`${pct}%`,background:b.color}}/></div><div style={{fontSize:"10px",color:"#718096"}}>{a.mt.filter(m=>m.ok).length}/{a.mt.length} micro-tâches</div></div>}
        <button style={{...S.gh,width:"100%",fontSize:"12px",padding:"7px"}} onClick={()=>setTaskId(a.id)}>Détail / micro-tâches / validation</button>
      </div>;
    })}
    {b.arts.some(a=>a.tech&&a.h>0)&&<button style={{...S.or,width:"100%",marginTop:"6px"}} onClick={()=>{const sched=buildSched(b.arts,b.s,b.e,b.hpd||5);up(x=>({...x,sched}));show("⚡ Planning généré !");}}>⚡ Générer le planning auto</button>}
    {addArt&&<AddArtSheet onClose={()=>setAddArt(false)} onAdd={art=>{up(x=>({...x,arts:[...x.arts,art]}));show("✅ Article ajouté !");}}/>}
  </>;
}

function AddArtSheet({onClose,onAdd}){
  const [f,setF]=useState({num:"",nom:"",prest:"Yacht Solutions",h:"",mt:""});
  const fd=(k,v)=>setF(p=>({...p,[k]:v}));
  return <Sheet title="Nouvel article" onClose={onClose}>
    <Lbl label="Nom *"><Inp value={f.nom} onChange={v=>fd("nom",v)} placeholder="ex : Installation Starlink"/></Lbl>
    <div style={{display:"flex",gap:"8px"}}><div style={{flex:1}}><Lbl label="N° article"><Inp value={f.num} onChange={v=>fd("num",v)} placeholder="15268"/></Lbl></div><div style={{flex:1}}><Lbl label="Heures"><Inp type="number" value={f.h} onChange={v=>fd("h",v)} placeholder="10"/></Lbl></div></div>
    <Lbl label="Prestataire"><Inp value={f.prest} onChange={v=>fd("prest",v)} placeholder="Yacht Solutions"/></Lbl>
    <Lbl label="Micro-tâches (une par ligne)">
      <textarea value={f.mt} onChange={e=>fd("mt",e.target.value)} placeholder={"Raccordement électrique\nTirage de câble\nFixation antenne"} rows={4}
        style={{width:"100%",background:"#0D1B2A",border:"1px solid #253650",borderRadius:"8px",padding:"9px",color:"#E2E8F0",fontSize:"13px",boxSizing:"border-box",outline:"none",resize:"vertical",fontFamily:"inherit"}}/>
    </Lbl>
    <button style={{...S.or,width:"100%"}} onClick={()=>{
      if(!f.nom.trim())return;
      const mt=f.mt.split("\n").map(l=>l.trim()).filter(Boolean).map((l,i)=>({id:Date.now()+i,l,ok:false,ph:null}));
      onAdd({id:"a"+Date.now(),num:f.num,nom:f.nom,prest:f.prest,h:parseFloat(f.h)||0,tech:"",done:false,photos:[],mt});
      onClose();
    }}>Ajouter l'article</button>
  </Sheet>;
}

// ── TÂCHE DETAIL ──────────────────────────────────
function TaskPage({art:a0,boat:b,up,back,show}){
  const art=b.arts.find(a=>a.id===a0.id)||a0;
  const [showMF,setShowMF]=useState(false);
  const [mTxt,setMTxt]=useState("");
  const pRef=useRef();
  const toggleM=id=>up(x=>({...x,arts:x.arts.map(a=>a.id!==art.id?a:{...a,mt:a.mt.map(m=>m.id===id?{...m,ok:!m.ok}:m)})}));
  const addMicros=()=>{const ls=mTxt.split("\n").map(l=>l.trim()).filter(Boolean);if(!ls.length)return;up(x=>({...x,arts:x.arts.map(a=>a.id!==art.id?a:{...a,mt:[...a.mt,...ls.map((l,i)=>({id:Date.now()+i,l,ok:false,ph:null}))]})}));setMTxt("");setShowMF(false);show(`✅ ${ls.length} micro-tâche${ls.length>1?"s":""} ajoutée${ls.length>1?"s":""} !`);};
  const addPhotoTask=e=>{const f=e.target.files[0];if(!f)return;const url=URL.createObjectURL(f);up(x=>({...x,arts:x.arts.map(a=>a.id!==art.id?a:{...a,photos:[...(a.photos||[]),{url,date:new Date().toLocaleDateString("fr-FR")}]})}));show("📸 Photo ajoutée !");e.target.value="";};
  const addPhotoMicro=(id,e)=>{const f=e.target.files[0];if(!f)return;const url=URL.createObjectURL(f);up(x=>({...x,arts:x.arts.map(a=>a.id!==art.id?a:{...a,mt:a.mt.map(m=>m.id===id?{...m,ph:url,ok:true}:m)})}));show("📸 Micro validée !");e.target.value="";};
  const validate=()=>{if(!(art.photos||[]).length){show("📸 Photo requise !",true);return;}up(x=>({...x,arts:x.arts.map(a=>a.id!==art.id?a:{...a,done:true})}));show("✅ Tâche validée !");setTimeout(back,1200);};
  const pct=art.mt.length?Math.round(art.mt.filter(m=>m.ok).length/art.mt.length*100):art.done?100:0;
  return <div style={{...S.root,position:"fixed",inset:0,zIndex:90,display:"flex",flexDirection:"column"}}>
    <div style={S.hdr}>
      <button style={S.ib} onClick={back}>{IC.back}</button>
      <div style={{flex:1}}><div style={{fontSize:"10px",color:b.color,textTransform:"uppercase",fontWeight:"700"}}>{b.name}</div><div style={{fontSize:"15px",fontWeight:"700",lineHeight:"1.3"}}>{art.nom}</div></div>
      <Ring pct={pct} color={b.color} size={42}/>
    </div>
    <div style={{flex:1,overflowY:"auto",padding:"14px",paddingBottom:"90px"}}>
      <div style={{display:"flex",...S.card,overflow:"hidden",marginBottom:"12px"}}>
        {[{l:"Tech",v:art.tech||"—"},{l:"Temps",v:art.h?`${art.h}h`:"—"},{l:"Statut",v:art.done?"✓ Validé":"En cours",c:art.done?"#22C55E":undefined}].map((x,i)=>(
          <div key={i} style={{flex:1,padding:"9px 6px",display:"flex",flexDirection:"column",alignItems:"center",gap:"2px",borderRight:i<2?"1px solid #1A2D42":"none"}}>
            <span style={{fontSize:"9px",color:"#4A5568",textTransform:"uppercase"}}>{x.l}</span>
            <span style={{fontSize:"12px",fontWeight:"600",color:x.c||"#E2E8F0"}}>{x.v}</span>
          </div>
        ))}
      </div>

      <div style={{...S.card,padding:"12px",marginBottom:"12px"}}>
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:"8px"}}>
          <span style={{fontSize:"13px",fontWeight:"700"}}>Micro-tâches</span>
          <button style={{...S.or,padding:"4px 9px",fontSize:"11px"}} onClick={()=>setShowMF(s=>!s)}>+ Ajouter</button>
        </div>
        {showMF&&<div style={{background:"#0D1B2A",border:"1px solid #253650",borderRadius:"8px",padding:"10px",marginBottom:"10px"}}>
          <div style={{fontSize:"11px",color:"#718096",marginBottom:"4px"}}>Une par ligne</div>
          <textarea value={mTxt} onChange={e=>setMTxt(e.target.value)} rows={4} placeholder={"Raccordement électrique\nTirage de câble\nFixation antenne"}
            style={{width:"100%",background:"transparent",border:"1px solid #253650",borderRadius:"7px",padding:"8px",color:"#E2E8F0",fontSize:"13px",boxSizing:"border-box",outline:"none",resize:"vertical",fontFamily:"inherit"}}/>
          <div style={{display:"flex",gap:"7px",marginTop:"7px"}}>
            <button style={{...S.gh,flex:1,fontSize:"12px",padding:"7px"}} onClick={()=>{setShowMF(false);setMTxt("");}}>Annuler</button>
            <button style={{...S.or,flex:2,fontSize:"12px",padding:"7px"}} onClick={addMicros}>Ajouter</button>
          </div>
        </div>}
        {art.mt.length===0&&<div style={{fontSize:"12px",color:"#4A5568"}}>Aucune micro-tâche</div>}
        {art.mt.map(m=><div key={m.id} style={{display:"flex",alignItems:"center",gap:"9px",padding:"7px 0",borderBottom:"1px solid #1A2D4222"}}>
          <button onClick={()=>toggleM(m.id)} style={{width:"22px",height:"22px",borderRadius:"5px",border:`2px solid ${m.ok?"#22C55E":"#4A5568"}`,background:m.ok?"#22C55E":"transparent",display:"flex",alignItems:"center",justifyContent:"center",cursor:"pointer",flexShrink:0,padding:0,color:"#fff"}}>{m.ok?IC.check:""}</button>
          <span style={{flex:1,fontSize:"13px",color:m.ok?"#718096":"#E2E8F0",textDecoration:m.ok?"line-through":"none"}}>{m.l}</span>
          <label style={{cursor:"pointer",flexShrink:0}}>
            {m.ph?<img src={m.ph} alt="" style={{width:"30px",height:"30px",objectFit:"cover",borderRadius:"5px",border:"1px solid #22C55E",display:"block"}}/>:<div style={{width:"30px",height:"30px",borderRadius:"5px",background:"#1A2D42",display:"flex",alignItems:"center",justifyContent:"center",color:"#718096",fontSize:"14px"}}>{IC.cam}</div>}
            <input type="file" accept="image/*" capture="environment" style={{display:"none"}} onChange={e=>addPhotoMicro(m.id,e)}/>
          </label>
        </div>)}
      </div>

      <div style={{...S.card,padding:"12px",marginBottom:"12px"}}>
        <div style={{fontSize:"13px",fontWeight:"700",marginBottom:"4px"}}>Photos de validation{(art.photos||[]).length===0&&<span style={{color:"#F59E0B",fontSize:"11px",fontWeight:"400"}}> (1 min. requise)</span>}</div>
        {(art.photos||[]).length>0&&<div style={{display:"flex",gap:"7px",flexWrap:"wrap",marginBottom:"10px"}}>
          {(art.photos||[]).map((p,i)=><div key={i}><img src={p.url} alt="" style={{width:"78px",height:"78px",objectFit:"cover",borderRadius:"7px",border:"1px solid #1A2D42",display:"block"}}/><div style={{fontSize:"9px",color:"#718096",textAlign:"center",marginTop:"2px"}}>{p.date}</div></div>)}
        </div>}
        <label style={{...S.gh,width:"100%",cursor:"pointer"}}>
          {IC.cam} Prendre une photo
          <input type="file" accept="image/*" capture="environment" ref={pRef} style={{display:"none"}} onChange={addPhotoTask}/>
        </label>
      </div>

      {!(art.photos||[]).length&&<div style={{display:"flex",alignItems:"center",gap:"7px",padding:"8px 11px",background:"#F59E0B11",borderRadius:"8px",marginBottom:"10px",border:"1px solid #F59E0B33"}}><span style={{color:"#F59E0B"}}>⚠</span><span style={{fontSize:"12px",color:"#F59E0B"}}>Ajoutez au moins 1 photo pour valider</span></div>}
      <button onClick={validate} style={{...S.or,width:"100%",background:(art.photos||[]).length?"linear-gradient(135deg,#22C55E,#16A34A)":"#253650",fontSize:"16px",fontWeight:"700",padding:"14px",opacity:(art.photos||[]).length?1:0.5,cursor:(art.photos||[]).length?"pointer":"not-allowed"}}>✓ Valider la tâche</button>
    </div>
  </div>;
}

// ── PLANNING TAB ──────────────────────────────────
function PlanTab({boat:b,up,show}){
  const dRef=useRef(null);
  if(!b.s||!b.e)return <div style={{textAlign:"center",padding:"40px",color:"#4A5568"}}>Définissez les dates dans Infos</div>;
  const wd=workDays(b.s,b.e);
  const dm={};wd.forEach(d=>{dm[d]=[];});
  b.arts.forEach(a=>(b.sched[a.id]||[]).forEach(s=>{if(dm[s.date])dm[s.date].push({art:a,hours:s.hours});}));
  const move=(aid,from,to)=>{if(from===to)return;up(x=>({...x,sched:{...x.sched,[aid]:(x.sched[aid]||[]).map(s=>s.date===from?{...s,date:to}:s)}}));show("🔀 Déplacé !");};
  if(!Object.keys(b.sched).length)return <div style={{textAlign:"center",padding:"40px",color:"#4A5568"}}><div style={{fontSize:"28px",marginBottom:"8px"}}>📅</div><div style={{marginBottom:"12px"}}>Assignez des techniciens dans Articles</div><button style={{...S.or}} onClick={()=>{const sched=buildSched(b.arts,b.s,b.e,b.hpd||5);up(x=>({...x,sched}));show("⚡ Planning généré !");}}>⚡ Générer maintenant</button></div>;
  return <div>
    {wd.map(day=>{
      const items=dm[day]||[];
      const bt={};items.forEach(it=>{const t=it.art.tech||"?";if(!bt[t])bt[t]=[];bt[t].push(it);});
      const isJ2=b.dep&&day===iso(addD(b.dep,-2)),isDep=b.dep&&day===b.dep;
      return <div key={day} style={{marginBottom:"10px"}} onDragOver={e=>e.preventDefault()} onDrop={e=>{e.preventDefault();const d=dRef.current;if(d)move(d.id,d.from,day);dRef.current=null;}}>
        <div style={{display:"flex",alignItems:"center",gap:"7px",padding:"6px 9px",...S.card,marginBottom:"4px",border:`1px solid ${isDep?"#F4821E":isJ2?"#F59E0B":"#1A2D42"}`}}>
          <div style={{flex:1}}><div style={{fontSize:"12px",fontWeight:"700"}}>{fmtL(day)}</div>{isDep&&<div style={{fontSize:"10px",color:"#F4821E",fontWeight:"700"}}>⚓ Départ</div>}{isJ2&&<div style={{fontSize:"10px",color:"#F59E0B",fontWeight:"700"}}>⚠ J-2</div>}</div>
          {items.length>0&&<span style={{fontSize:"12px",color:"#F4821E",fontWeight:"700"}}>{items.reduce((s,i)=>s+i.hours,0)}h</span>}
        </div>
        {Object.entries(bt).map(([t,its])=><div key={t} style={{paddingLeft:"8px",borderLeft:"2px solid #253650",marginBottom:"4px"}}>
          <div style={{fontSize:"10px",color:"#718096",marginBottom:"3px"}}>{t}</div>
          {its.map(it=><div key={it.art.id} draggable onDragStart={()=>{dRef.current={id:it.art.id,from:day};}} onDragEnd={()=>{dRef.current=null;}}
            style={{background:b.color+"22",border:`1px solid ${b.color}44`,borderRadius:"6px",padding:"5px 9px",marginBottom:"3px",cursor:"grab",display:"flex",alignItems:"center",gap:"7px"}}>
            <span style={{color:"#4A5568",fontSize:"12px"}}>{IC.drag}</span>
            <span style={{flex:1,fontSize:"12px",fontWeight:"600"}}>{it.art.nom}</span>
            <span style={{fontSize:"11px",color:"#F4821E",fontWeight:"700"}}>{it.hours}h</span>
          </div>)}
        </div>)}
        {items.length===0&&<div style={{fontSize:"11px",color:"#4A5568",paddingLeft:"8px",fontStyle:"italic"}}>Aucune tâche</div>}
      </div>;
    })}
  </div>;
}

// ── SEMAINE ───────────────────────────────────────
function Week({boats}){
  const now=new Date();
  const isoW=s=>{const d=pd(s),j=new Date(Date.UTC(d.getFullYear(),d.getMonth(),d.getDate())),dw=j.getUTCDay()||7;j.setUTCDate(j.getUTCDate()+4-dw);const y=new Date(Date.UTC(j.getUTCFullYear(),0,1));return Math.ceil((((j-y)/86400000)+1)/7);};
  const [wk,setWk]=useState(()=>isoW(iso(now)));
  const [yr,setYr]=useState(now.getFullYear());
  const pw=()=>{if(wk<=1){setWk(52);setYr(y=>y-1);}else setWk(w=>w-1);};
  const nw=()=>{if(wk>=52){setWk(1);setYr(y=>y+1);}else setWk(w=>w+1);};
  const items=[];
  boats.forEach(b=>(b.arts||[]).forEach(a=>((b.sched||{})[a.id]||[]).forEach(s=>{const d=pd(s.date);if(d&&d.getFullYear()===yr&&isoW(s.date)===wk)items.push({boat:b,art:a,date:s.date,hours:s.hours});})));
  const byDay={};items.forEach(i=>{if(!byDay[i.date])byDay[i.date]=[];byDay[i.date].push(i);});
  const byTech={};items.forEach(i=>{const t=i.art.tech||"—";if(!byTech[t])byTech[t]={h:0,n:0};byTech[t].h+=i.hours;byTech[t].n++;});
  const totalH=items.reduce((s,i)=>s+i.hours,0);

  const exportPDF=()=>{
    const bT={};items.forEach(i=>{const t=i.art.tech||"Non assigné";if(!bT[t])bT[t]={};if(!bT[t][i.date])bT[t][i.date]=[];bT[t][i.date].push(i);});
    const blocks=Object.entries(bT).map(([t,days])=>{
      const th=Object.values(days).flat().reduce((s,i)=>s+i.hours,0);
      const rows=Object.entries(days).sort(([a],[b])=>a.localeCompare(b)).map(([date,its])=>
        `<tr style="background:#EBF4FF"><td colspan="3" style="padding:7px 10px;font-size:13px;font-weight:700;color:#1E3A5F;border-top:2px solid #1E4D8C">${pd(date).toLocaleDateString("fr-FR",{weekday:"long",day:"numeric",month:"long"})}</td></tr>`+
        its.map(i=>`<tr><td style="padding:5px 10px;font-size:11px;color:#1E4D8C;font-weight:700">${i.boat.name}</td><td style="padding:5px 10px;font-size:12px">${i.art.nom}</td><td style="padding:5px 10px;font-size:12px;color:#F4821E;font-weight:700;text-align:center">${i.hours}h</td></tr>`).join("")
      );
      return `<div style="margin-bottom:28px;page-break-inside:avoid"><div style="background:#0D1B2A;color:#fff;padding:10px 14px;border-radius:8px 8px 0 0;display:flex;justify-content:space-between"><div style="font-size:16px;font-weight:800">${t}</div><div style="font-size:12px;opacity:.7">S${wk} · ${th}h</div></div><table style="width:100%;border-collapse:collapse;border:1px solid #ddd;border-top:none"><thead><tr style="background:#F4821E;color:#fff"><th style="padding:6px 10px;text-align:left;font-size:11px">Bateau</th><th style="padding:6px 10px;text-align:left;font-size:11px">Tâche</th><th style="padding:6px 10px;text-align:center;font-size:11px">H</th></tr></thead><tbody>${rows}</tbody></table></div>`;
    }).join("");
    const html=`<!DOCTYPE html><html><head><meta charset="utf-8"><title>Planning S${wk}-${yr}</title><style>*{box-sizing:border-box}body{font-family:Arial,sans-serif;margin:0;padding:20px}@media print{@page{margin:12mm}}</style></head><body><div style="display:flex;justify-content:space-between;align-items:center;padding-bottom:14px;margin-bottom:20px;border-bottom:3px solid #F4821E"><div><div style="font-size:22px;font-weight:900;color:#0D1B2A">⚓ YACHT SOLUTIONS</div><div style="color:#718096;font-size:13px">Planning — Semaine ${wk} / ${yr}</div></div><div style="text-align:right"><div style="font-size:11px;color:#888">Généré le ${new Date().toLocaleDateString("fr-FR",{day:"numeric",month:"long",year:"numeric"})}</div><div style="font-size:15px;font-weight:800;color:#F4821E">${Object.keys(bT).length} tech · ${totalH}h</div></div></div>${blocks||'<p style="color:#888;text-align:center;padding:40px">Aucune tâche planifiée</p>'}</body></html>`;
    const w=window.open("","_blank");if(!w){alert("Autorisez les pop-ups");return;}w.document.write(html);w.document.close();setTimeout(()=>{w.focus();w.print();},600);
  };

  return <div style={{padding:"14px",paddingBottom:"90px"}}>
    <div style={{display:"flex",alignItems:"center",gap:"10px",marginBottom:"12px"}}>
      <button style={{...S.gh,padding:"7px 11px",fontSize:"16px"}} onClick={pw}>‹</button>
      <div style={{flex:1,textAlign:"center"}}><div style={{fontSize:"16px",fontWeight:"700"}}>Semaine {wk}</div><div style={{fontSize:"11px",color:"#718096"}}>{yr}</div></div>
      <button style={{...S.gh,padding:"7px 11px",fontSize:"16px"}} onClick={nw}>›</button>
    </div>
    <button style={{...S.or,width:"100%",marginBottom:"12px",fontSize:"13px"}} onClick={exportPDF}>{IC.pdf} Exporter PDF — S{wk}</button>
    <div style={{display:"flex",gap:"8px",marginBottom:"12px"}}>
      {[{v:totalH+"h",l:"Total",c:"#F4821E"},{v:items.length,l:"Tâches",c:"#E2E8F0"},{v:Object.keys(byTech).filter(t=>t!=="—").length,l:"Techs",c:"#22C55E"}].map(s=>(
        <div key={s.l} style={{flex:1,...S.card,padding:"9px",textAlign:"center"}}><div style={{fontSize:"20px",fontWeight:"800",color:s.c}}>{s.v}</div><div style={{fontSize:"10px",color:"#4A5568"}}>{s.l}</div></div>
      ))}
    </div>
    {Object.keys(byTech).length>0&&<div style={{...S.card,padding:"11px",marginBottom:"12px"}}>
      <div style={{fontSize:"11px",color:"#718096",fontWeight:"700",textTransform:"uppercase",marginBottom:"7px"}}>Par technicien</div>
      {Object.entries(byTech).map(([t,d])=><div key={t} style={{display:"flex",alignItems:"center",gap:"8px",padding:"4px 0",borderTop:"1px solid #1A2D4233"}}>
        <span style={{fontSize:"12px"}}>{IC.user}</span><span style={{flex:1,fontSize:"13px",fontWeight:"600"}}>{t}</span>
        <span style={{fontSize:"12px",color:"#F4821E",fontWeight:"700"}}>{d.h}h</span><span style={{fontSize:"11px",color:"#4A5568"}}>{d.n} tâche{d.n>1?"s":""}</span>
      </div>)}
    </div>}
    {Object.keys(byDay).sort().map(day=>{
      const dis=byDay[day],dH=dis.reduce((s,i)=>s+i.hours,0);
      return <div key={day} style={{marginBottom:"10px"}}>
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:"5px"}}><span style={{fontSize:"13px",fontWeight:"700",color:"#CBD5E0"}}>{fmtL(day)}</span><span style={{fontSize:"12px",color:"#F4821E",fontWeight:"700"}}>{dH}h</span></div>
        {dis.map((it,i)=>{const p=it.art.mt.length?Math.round(it.art.mt.filter(m=>m.ok).length/it.art.mt.length*100):it.art.done?100:0;
          return <div key={i} style={{...S.card,padding:"9px 11px",marginBottom:"5px",borderLeft:`3px solid ${it.boat.color}`}}>
            <div style={{display:"flex",alignItems:"center",gap:"8px"}}>
              <div style={{flex:1}}><div style={{fontSize:"10px",color:it.boat.color,fontWeight:"700",textTransform:"uppercase"}}>{it.boat.name}</div><div style={{fontSize:"13px",fontWeight:"600"}}>{it.art.nom}</div><div style={{fontSize:"11px",color:"#718096",display:"flex",gap:"8px",marginTop:"2px"}}><span>{IC.user} {it.art.tech||"—"}</span><span>{it.hours}h</span></div></div>
              <Ring pct={p} color={it.boat.color} size={34}/>
            </div>
          </div>;})}
      </div>;
    })}
    {items.length===0&&<div style={{textAlign:"center",padding:"50px 0",color:"#4A5568"}}><div style={{fontSize:"32px",marginBottom:"8px"}}>⚓</div>Aucune tâche planifiée cette semaine</div>}
  </div>;
}

// ── JOURNÉE ───────────────────────────────────────
function Day({boats}){
  const [sel,setSel]=useState(iso(new Date()));
  const items=[];
  boats.forEach(b=>(b.arts||[]).forEach(a=>((b.sched||{})[a.id]||[]).filter(s=>s.date===sel).forEach(s=>items.push({boat:b,art:a,hours:s.hours,sh:b.sh||"08:00"}))));
  const byTech={};items.forEach(i=>{const t=i.art.tech||"Non assigné";if(!byTech[t])byTech[t]=[];byTech[t].push(i);});
  const ph=s=>{const[h,m]=s.split(":").map(Number);return h+m/60;};
  const fh=n=>{const h=Math.floor(n),m=Math.round((n-h)*60);return`${String(h).padStart(2,"0")}:${String(m).padStart(2,"0")}`;};
  return <div style={{padding:"14px",paddingBottom:"90px"}}>
    <div style={{display:"flex",alignItems:"center",gap:"10px",marginBottom:"12px"}}>
      <button style={{...S.gh,padding:"7px 11px",fontSize:"16px"}} onClick={()=>setSel(d=>iso(addD(d,-1)))}>‹</button>
      <div style={{flex:1,textAlign:"center"}}><div style={{fontSize:"16px",fontWeight:"700"}}>{fmtL(sel)}</div><div style={{fontSize:"11px",color:"#718096"}}>{items.reduce((s,i)=>s+i.hours,0)}h planifiées</div></div>
      <button style={{...S.gh,padding:"7px 11px",fontSize:"16px"}} onClick={()=>setSel(d=>iso(addD(d,1)))}>›</button>
    </div>
    <div style={{marginBottom:"14px"}}><Inp type="date" value={sel} onChange={setSel}/></div>
    {items.length===0&&<div style={{textAlign:"center",padding:"50px 0",color:"#4A5568"}}><div style={{fontSize:"32px",marginBottom:"8px"}}>☀️</div>Aucune tâche ce jour</div>}
    {Object.entries(byTech).map(([tech,its])=>{
      let cur=ph(its[0].sh||"08:00");
      return <div key={tech} style={{marginBottom:"20px"}}>
        <div style={{display:"flex",alignItems:"center",gap:"8px",marginBottom:"8px"}}>
          <span style={{fontSize:"14px"}}>{IC.user}</span><span style={{fontSize:"14px",fontWeight:"700"}}>{tech}</span>
          <span style={{marginLeft:"auto",fontSize:"12px",fontWeight:"700",color:"#F4821E"}}>{its.reduce((s,i)=>s+i.hours,0)}h</span>
        </div>
        {its.map((it,i)=>{const s=cur,e=cur+it.hours;cur=e;const p=it.art.mt.length?Math.round(it.art.mt.filter(m=>m.ok).length/it.art.mt.length*100):it.art.done?100:0;
          return <div key={i} style={{display:"flex",gap:"8px",marginBottom:"7px",alignItems:"stretch"}}>
            <div style={{width:"42px",flexShrink:0,display:"flex",flexDirection:"column",alignItems:"center"}}>
              <div style={{fontSize:"11px",color:"#F4821E",fontWeight:"700"}}>{fh(s)}</div>
              <div style={{flex:1,width:"2px",background:"#1A2D42",margin:"2px 0"}}/>
              <div style={{fontSize:"10px",color:"#718096"}}>{fh(e)}</div>
            </div>
            <div style={{flex:1,...S.card,padding:"9px 11px",borderLeft:`3px solid ${it.boat.color}`}}>
              <div style={{display:"flex",alignItems:"flex-start",gap:"8px"}}>
                <div style={{flex:1}}><div style={{fontSize:"10px",color:it.boat.color,fontWeight:"700",textTransform:"uppercase"}}>{it.boat.name}</div><div style={{fontSize:"13px",fontWeight:"600",marginBottom:"4px"}}>{it.art.nom}</div>
                  <span style={{padding:"2px 7px",borderRadius:"10px",fontSize:"11px",background:"#F4821E22",color:"#F4821E",fontWeight:"600"}}>{it.hours}h</span>
                </div>
                <Ring pct={p} color={it.boat.color} size={34}/>
              </div>
              {it.art.mt.length>0&&<><div style={{height:"3px",background:"#1A2D42",borderRadius:"2px",overflow:"hidden",marginTop:"7px",marginBottom:"3px"}}><div style={{height:"100%",width:`${p}%`,background:it.boat.color}}/></div><div style={{fontSize:"10px",color:"#718096"}}>{it.art.mt.filter(m=>m.ok).length}/{it.art.mt.length} micro-tâches</div></>}
            </div>
          </div>;})}
      </div>;
    })}
  </div>;
}

// ── QC ────────────────────────────────────────────
function QC({boats,setBoats}){
  const [bId,setBId]=useState(null);
  const [aId,setAId]=useState(null);
  const boat=bId?boats.find(b=>b.id===bId):null;
  const art=boat&&aId?boat.arts.find(a=>a.id===aId):null;

  if(art&&boat)return <QCDetail boat={boat} art={art} setBoats={setBoats} back={()=>setAId(null)}/>;
  if(boat)return <QCBoat boat={boat} setAId={setAId} back={()=>setBId(null)}/>;
  return <div style={{padding:"14px",paddingBottom:"90px"}}>
    <div style={{fontSize:"17px",fontWeight:"700",marginBottom:"3px"}}>Contrôle Qualité</div>
    <div style={{fontSize:"12px",color:"#718096",marginBottom:"14px"}}>Sélectionnez un bateau</div>
    {boats.filter(b=>b.arts?.length>0).map(b=>{
      const nOk=b.arts.filter(a=>qcSteps(a.prest).every(s=>b.qc[a.id]?.[s.id]?.r===true)).length;
      const pct=b.arts.length?Math.round(nOk/b.arts.length*100):0;
      return <button key={b.id} onClick={()=>setBId(b.id)} style={{width:"100%",marginBottom:"9px",...S.card,padding:"13px",cursor:"pointer",textAlign:"left",fontFamily:"inherit",display:"flex",alignItems:"center",gap:"11px"}}>
        <div style={{width:"10px",height:"10px",borderRadius:"2px",background:b.color,flexShrink:0}}/>
        <div style={{flex:1}}><div style={{fontSize:"14px",fontWeight:"700"}}>{b.name}</div><div style={{fontSize:"11px",color:"#718096"}}>{b.model} · {b.arts.length} articles</div>
          <div style={{height:"3px",background:"#1A2D42",borderRadius:"2px",overflow:"hidden",marginTop:"6px"}}><div style={{height:"100%",width:`${pct}%`,background:pct===100?"#22C55E":b.color}}/></div>
        </div>
        <div style={{textAlign:"right"}}><div style={{fontSize:"20px",fontWeight:"800",color:pct===100?"#22C55E":"#F4821E"}}>{pct}%</div></div>
      </button>;
    })}
    {boats.filter(b=>b.arts?.length>0).length===0&&<div style={{textAlign:"center",padding:"50px",color:"#4A5568"}}>Aucun bateau avec articles</div>}
  </div>;
}

function QCBoat({boat:b,setAId,back}){
  const nOk=b.arts.filter(a=>qcSteps(a.prest).every(s=>b.qc[a.id]?.[s.id]?.r===true)).length;
  const pct=b.arts.length?Math.round(nOk/b.arts.length*100):0;
  return <div style={{...S.root,position:"fixed",inset:0,zIndex:80,display:"flex",flexDirection:"column"}}>
    <div style={S.hdr}><button style={S.ib} onClick={back}>{IC.back}</button><div style={{flex:1}}><div style={{fontSize:"10px",color:b.color,textTransform:"uppercase",fontWeight:"700"}}>{b.model}</div><div style={{fontSize:"16px",fontWeight:"700"}}>{b.name} — QC</div></div></div>
    <div style={{flex:1,overflowY:"auto",padding:"14px",paddingBottom:"40px"}}>
      <div style={{display:"flex",justifyContent:"space-between",marginBottom:"6px"}}><span style={{fontSize:"13px",color:"#718096"}}>{b.arts.length} articles</span><span style={{fontSize:"22px",fontWeight:"800",color:pct===100?"#22C55E":"#F4821E"}}>{pct}%</span></div>
      <div style={{height:"5px",background:"#1A2D42",borderRadius:"3px",overflow:"hidden",marginBottom:"14px"}}><div style={{height:"100%",width:`${pct}%`,background:"linear-gradient(90deg,#F4821E,#22C55E)"}}/></div>
      {b.arts.map(a=>{
        const steps=qcSteps(a.prest),ac=b.qc[a.id]||{};
        const dn=steps.filter(s=>ac[s.id]).length,allOk=steps.every(s=>ac[s.id]?.r===true),hasI=steps.some(s=>ac[s.id]?.r===false);
        const sc=dn===0?"#4A5568":allOk?"#22C55E":hasI?"#F59E0B":"#F4821E";
        const sl=dn===0?"À contrôler":allOk?"Validé ✓":hasI?"Remarques":"En cours";
        return <button key={a.id} onClick={()=>setAId(a.id)} style={{width:"100%",...S.card,padding:"0",marginBottom:"8px",cursor:"pointer",textAlign:"left",fontFamily:"inherit",display:"block",border:`1px solid ${allOk?"#22C55E44":hasI?"#F59E0B44":"#1A2D42"}`}}>
          <div style={{display:"flex",alignItems:"center"}}>
            <div style={{width:"4px",alignSelf:"stretch",background:BOIS.includes(a.prest)?"#B45309":"#1E4D8C",borderRadius:"10px 0 0 10px",flexShrink:0}}/>
            <div style={{flex:1,padding:"9px 11px"}}>
              <div style={{display:"flex",justifyContent:"space-between",marginBottom:"4px"}}>
                <div style={{fontSize:"13px",fontWeight:"600",lineHeight:"1.3"}}>{a.nom}</div>
                <span style={{padding:"2px 8px",borderRadius:"20px",fontSize:"10px",fontWeight:"600",color:sc,background:sc+"22",whiteSpace:"nowrap"}}>{sl}</span>
              </div>
              <div style={{display:"flex",gap:"4px",alignItems:"center"}}>{steps.map(s=>{const c=ac[s.id];return <div key={s.id} style={{flex:1,height:"3px",borderRadius:"2px",background:!c?"#253650":c.r?"#22C55E":"#F59E0B"}}/>;})} <span style={{fontSize:"10px",color:"#4A5568",marginLeft:"4px"}}>{dn}/{steps.length}</span></div>
            </div>
          </div>
        </button>;
      })}
    </div>
  </div>;
}

function QCDetail({boat:b,art:a0,setBoats,back}){
  const a=b.arts.find(x=>x.id===a0.id)||a0;
  const steps=qcSteps(a.prest),checks=b.qc[a.id]||{};
  const first=steps.find(s=>!checks[s.id]);
  const [cur,setCur]=useState(first?.id||steps[0]?.id);
  const [rem,setRem]=useState("");const [showR,setShowR]=useState(false);
  const set=(sid,val)=>{setBoats(p=>p.map(x=>x.id!==b.id?x:{...x,qc:{...x.qc,[a.id]:{...(x.qc[a.id]||{}),[sid]:val}}}));const i=steps.findIndex(s=>s.id===sid);const nx=steps.slice(i+1).find(s=>!checks[s.id]);if(nx)setCur(nx.id);setShowR(false);setRem("");};
  const liveChecks=b.qc[a.id]||{};
  return <div style={{...S.root,position:"fixed",inset:0,zIndex:90,display:"flex",flexDirection:"column"}}>
    <div style={S.hdr}><button style={S.ib} onClick={back}>{IC.back}</button><div style={{flex:1}}><div style={{fontSize:"10px",color:"#718096"}}>{b.name}</div><div style={{fontSize:"14px",fontWeight:"700",lineHeight:"1.3"}}>{a.nom}</div></div></div>
    <div style={{flex:1,overflowY:"auto",padding:"14px",paddingBottom:"40px"}}>
      <div style={{display:"flex",gap:"5px",marginBottom:"14px"}}>
        {steps.map((s,i)=>{const c=liveChecks[s.id],isA=cur===s.id;
          return <button key={s.id} onClick={()=>setCur(s.id)} style={{flex:1,padding:"7px 3px",borderRadius:"8px",border:`2px solid ${isA?"#F4821E":c?(c.r?"#22C55E":"#F59E0B"):"#253650"}`,background:isA?"#F4821E15":"transparent",cursor:"pointer",display:"flex",flexDirection:"column",alignItems:"center",gap:"3px"}}>
            <div style={{width:"20px",height:"20px",borderRadius:"50%",background:c?(c.r?"#22C55E":"#F59E0B"):"#253650",display:"flex",alignItems:"center",justifyContent:"center",fontSize:"11px",color:"#fff",fontWeight:"700"}}>{c?(c.r?IC.check:"!"):(i+1)}</div>
            <span style={{fontSize:"9px",color:isA?"#F4821E":c?(c.r?"#22C55E":"#F59E0B"):"#718096",textAlign:"center",lineHeight:"1.2"}}>{s.l}</span>
          </button>;
        })}
      </div>
      {steps.filter(s=>s.id===cur).map(step=>{const c=liveChecks[step.id];
        return <div key={step.id}>
          <div style={{...S.card,padding:"13px",marginBottom:"14px"}}><div style={{fontSize:"15px",fontWeight:"700",marginBottom:"3px"}}>{step.l}</div><div style={{fontSize:"12px",color:"#718096"}}>Vérifiez et validez ce point</div></div>
          {!c?<>
            {showR&&<textarea value={rem} onChange={e=>setRem(e.target.value)} placeholder="Décrivez le problème…" rows={3} style={{width:"100%",background:"#0D1B2A",border:"1px solid #253650",borderRadius:"8px",padding:"9px",color:"#E2E8F0",fontSize:"13px",boxSizing:"border-box",outline:"none",resize:"none",fontFamily:"inherit",marginBottom:"9px"}}/>}
            <div style={{display:"flex",gap:"10px"}}>
              <button style={{flex:1,padding:"16px",borderRadius:"10px",border:"2px solid #EF4444",background:"#EF444415",color:"#EF4444",cursor:"pointer",fontSize:"18px",fontWeight:"700",fontFamily:"inherit"}} onClick={()=>{if(!showR)setShowR(true);else set(step.id,{r:false,note:rem,date:new Date().toLocaleDateString("fr-FR")});}}>{showR?"Confirmer NON":"✗ NON"}</button>
              <button style={{flex:1,padding:"16px",borderRadius:"10px",border:"2px solid #22C55E",background:"#22C55E15",color:"#22C55E",cursor:"pointer",fontSize:"18px",fontWeight:"700",fontFamily:"inherit"}} onClick={()=>set(step.id,{r:true,note:"",date:new Date().toLocaleDateString("fr-FR")})}>✓ OUI</button>
            </div>
            {showR&&<button style={{marginTop:"8px",background:"transparent",border:"none",color:"#718096",cursor:"pointer",fontSize:"12px",width:"100%",fontFamily:"inherit"}} onClick={()=>{setShowR(false);setRem("");}}>Annuler</button>}
          </>:<div style={{background:c.r?"#22C55E15":"#F59E0B15",border:`1px solid ${c.r?"#22C55E":"#F59E0B"}`,borderRadius:"10px",padding:"12px"}}>
            <div style={{display:"flex",alignItems:"center",gap:"10px",marginBottom:c.note?"9px":"0"}}>
              <span style={{fontSize:"24px"}}>{c.r?"✓":"!"}</span>
              <div><div style={{fontWeight:"700",color:c.r?"#22C55E":"#F59E0B"}}>{c.r?"Validé":"Non conforme"}</div><div style={{fontSize:"11px",color:"#718096"}}>le {c.date}</div></div>
              <button style={{marginLeft:"auto",...S.gh,padding:"4px 9px",fontSize:"11px"}} onClick={()=>set(step.id,null)}>Modifier</button>
            </div>
            {c.note&&<div style={{fontSize:"12px",background:"#0D1B2A",padding:"8px",borderRadius:"7px",borderLeft:"3px solid #F59E0B"}}>💬 {c.note}</div>}
          </div>}
        </div>;
      })}
    </div>
  </div>;
}

// ── IMPORT ────────────────────────────────────────
const DEMO=`Num,Nom,Prestataire,Heures,Microtaches\n15268,Installation Starlink,Yacht Solutions,10,Pose antenne|Tirage câble|Configuration\n15651,Prise 220V,Yacht Solutions,8,Perçage|Raccordement|Test\n,Écran Axiom 12,Yacht Solutions,4,Montage|Connexion NMEA\n16832,Système son Bower,Yacht Solutions,6,Câblage|Ampli|Test son\n18514,Stickers étraves,Métamorchose,3,Nettoyage|Pose|Finition`;

function Import({boats,setBoats,show}){
  const [step,setStep]=useState("form");
  const [f,setF]=useState({name:"",model:"",owner:"",s:"",e:"",dep:"",hpd:"5",sh:"08:00"});
  const [color,setColor]=useState(COLORS[2]);
  const [preview,setPreview]=useState(null);
  const fRef=useRef();
  const fd=(k,v)=>setF(p=>({...p,[k]:v}));

  const parse=txt=>{
    const lines=txt.split("\n").map(l=>l.trim()).filter(Boolean);
    const arts=[];
    lines.forEach((line,i)=>{
      if(i===0)return;
      const cols=line.split(/[,;\t]/).map(c=>c.trim().replace(/^"|"$/g,""));
      if(cols.length<2)return;
      const nom=cols[1]||cols[0]||"";if(!nom)return;
      const mt=(cols[4]||"").split("|").map(l=>l.trim()).filter(Boolean);
      arts.push({id:"a"+Date.now()+Math.random().toString(36).slice(2),num:cols[0]||"",nom,prest:cols[2]||"Yacht Solutions",h:parseFloat(cols[3])||0,tech:"",done:false,photos:[],mt:mt.map((l,j)=>({id:Date.now()+j,l,ok:false,ph:null}))});
    });
    return arts;
  };

  const go=txt=>{
    const arts=parse(txt);
    if(!arts.length){show("Aucun article détecté",true);return;}
    setPreview({id:Date.now(),name:f.name.trim()||"Nouveau bateau",model:f.model,owner:f.owner,color,s:f.s,e:f.e,dep:f.dep,hpd:Number(f.hpd),sh:f.sh,annots:[],docs:[],arts,sched:{},qc:{}});
    setStep("preview");
  };

  return <div style={{padding:"14px",paddingBottom:"90px"}}>
    <div style={{fontSize:"17px",fontWeight:"700",marginBottom:"3px"}}>Import PDF / Excel</div>
    <div style={{fontSize:"12px",color:"#718096",marginBottom:"14px"}}>Renseignez le bateau puis importez</div>

    {step==="form"&&<>
      <div style={{...S.card,padding:"13px",marginBottom:"12px"}}>
        <div style={{fontSize:"11px",color:"#718096",fontWeight:"700",textTransform:"uppercase",marginBottom:"9px"}}>Infos du bateau</div>
        <Lbl label="Nom *"><Inp value={f.name} onChange={v=>fd("name",v)} placeholder="ex : L60 #17"/></Lbl>
        <div style={{display:"flex",gap:"8px"}}><div style={{flex:1}}><Lbl label="Modèle"><Inp value={f.model} onChange={v=>fd("model",v)} placeholder="Lagoon 60"/></Lbl></div><div style={{flex:1}}><Lbl label="Propriétaire"><Inp value={f.owner} onChange={v=>fd("owner",v)} placeholder="J. Dupont"/></Lbl></div></div>
        <div style={{display:"flex",gap:"8px"}}><div style={{flex:1}}><Lbl label="Début"><Inp type="date" value={f.s} onChange={v=>fd("s",v)}/></Lbl></div><div style={{flex:1}}><Lbl label="Fin"><Inp type="date" value={f.e} onChange={v=>fd("e",v)}/></Lbl></div></div>
        <Lbl label="Départ client ⚓"><Inp type="date" value={f.dep} onChange={v=>fd("dep",v)}/></Lbl>
        <div style={{display:"flex",gap:"8px"}}><div style={{flex:1}}><Lbl label="Heure début"><Inp type="time" value={f.sh} onChange={v=>fd("sh",v)}/></Lbl></div><div style={{flex:1}}><Lbl label="H/jour"><Sel value={f.hpd} onChange={v=>fd("hpd",v)} opts={[3,4,5,6,7,8].map(n=>({v:String(n),l:`${n}h`}))}/></Lbl></div></div>
        <Lbl label="Couleur"><div style={{display:"flex",gap:"6px",flexWrap:"wrap"}}>{COLORS.map(c=><button key={c} onClick={()=>setColor(c)} style={{width:"28px",height:"28px",borderRadius:"7px",background:c,border:color===c?"3px solid #fff":"3px solid transparent",cursor:"pointer"}}/>)}</div></Lbl>
      </div>
      <input type="file" accept=".xlsx,.csv,.xls,.pdf,.txt" ref={fRef} style={{display:"none"}} onChange={e=>{const f2=e.target.files[0];if(!f2)return;e.target.value="";if(f2.name.toLowerCase().endsWith(".pdf")){show("PDF → import démo");go(DEMO);return;}const r=new FileReader();r.onload=ev=>go(ev.target.result);r.readAsText(f2,"UTF-8");}}/>
      <button style={{...S.or,width:"100%",marginBottom:"9px"}} onClick={()=>{if(!f.name.trim()){show("Donnez un nom au bateau",true);return;}fRef.current?.click();}}>📁 Importer fichier (CSV / XLS / PDF)</button>
      <button style={{...S.gh,width:"100%"}} onClick={()=>{if(!f.name.trim()){show("Donnez un nom au bateau",true);return;}go(DEMO);}}>⚡ Simuler import (démo)</button>
    </>}

    {step==="preview"&&preview&&<>
      <div style={{fontSize:"14px",fontWeight:"600",marginBottom:"10px"}}>{preview.arts.length} articles — vérifiez puis validez</div>
      <div style={{...S.card,padding:"12px",marginBottom:"12px",borderLeft:`4px solid ${preview.color}`}}>
        <div style={{display:"flex",alignItems:"center",gap:"9px",marginBottom:"8px"}}>
          <div style={{width:"10px",height:"10px",borderRadius:"2px",background:preview.color}}/>
          <div><div style={{fontWeight:"700"}}>{preview.name}</div><div style={{fontSize:"12px",color:"#718096"}}>{preview.model}{preview.owner?` · ${preview.owner}`:""}</div></div>
        </div>
        {preview.s&&<div style={{fontSize:"12px",color:"#718096",marginBottom:"8px"}}>{fmt(preview.s)} → {fmt(preview.e)}{preview.dep?` · ⚓ ${fmt(preview.dep)}`:""} · {preview.hpd}h/j</div>}
        <div style={{maxHeight:"240px",overflowY:"auto"}}>
          {preview.arts.map((a,i)=><div key={i} style={{padding:"5px 0",borderTop:"1px solid #1A2D4233"}}>
            <div style={{fontSize:"12px",fontWeight:"600"}}>{a.nom}{a.h?` — ${a.h}h`:""}</div>
            <div style={{fontSize:"11px",color:"#718096"}}>{a.prest}{a.mt.length?` · ${a.mt.length} micro-tâches`:""}</div>
          </div>)}
        </div>
      </div>
      <div style={{display:"flex",gap:"8px"}}>
        <button style={{...S.gh,flex:1}} onClick={()=>setStep("form")}>Modifier</button>
        <button style={{...S.or,flex:2}} onClick={()=>{setBoats(p=>[...p,preview]);show(`✅ ${preview.name} — ${preview.arts.length} articles importés !`);setStep("done");}}>✓ Valider</button>
      </div>
    </>}

    {step==="done"&&<div style={{textAlign:"center",padding:"40px 0"}}>
      <div style={{fontSize:"48px",marginBottom:"12px"}}>🎉</div>
      <div style={{color:"#22C55E",fontWeight:"700",fontSize:"16px",marginBottom:"6px"}}>Import réussi !</div>
      <div style={{color:"#718096",fontSize:"13px",marginBottom:"20px"}}>{preview?.arts.length} articles · QC et planning prêts</div>
      <button style={S.or} onClick={()=>{setStep("form");setF({name:"",model:"",owner:"",s:"",e:"",dep:"",hpd:"5",sh:"08:00"});setPreview(null);}}>Nouvel import</button>
    </div>}
  </div>;
}

// ── MODAL NOUVEAU BATEAU ──────────────────────────
function NewBoat({onClose,onAdd}){
  const [f,setF]=useState({name:"",model:"",owner:"",s:"",e:"",dep:"",hpd:"5",sh:"08:00"});
  const [color,setColor]=useState(COLORS[0]);
  const fd=(k,v)=>setF(p=>({...p,[k]:v}));
  return <Sheet title="Nouveau bateau" onClose={onClose}>
    <Lbl label="Nom *"><Inp value={f.name} onChange={v=>fd("name",v)} placeholder="ex : L60 #17"/></Lbl>
    <div style={{display:"flex",gap:"8px"}}><div style={{flex:1}}><Lbl label="Modèle"><Inp value={f.model} onChange={v=>fd("model",v)} placeholder="Lagoon 60"/></Lbl></div><div style={{flex:1}}><Lbl label="Propriétaire"><Inp value={f.owner} onChange={v=>fd("owner",v)} placeholder="J. Dupont"/></Lbl></div></div>
    <div style={{display:"flex",gap:"8px"}}><div style={{flex:1}}><Lbl label="Début"><Inp type="date" value={f.s} onChange={v=>fd("s",v)}/></Lbl></div><div style={{flex:1}}><Lbl label="Fin"><Inp type="date" value={f.e} onChange={v=>fd("e",v)}/></Lbl></div></div>
    <Lbl label="Départ client ⚓"><Inp type="date" value={f.dep} onChange={v=>fd("dep",v)}/></Lbl>
    <div style={{display:"flex",gap:"8px"}}><div style={{flex:1}}><Lbl label="Heure début"><Inp type="time" value={f.sh} onChange={v=>fd("sh",v)}/></Lbl></div><div style={{flex:1}}><Lbl label="H/jour"><Sel value={f.hpd} onChange={v=>fd("hpd",v)} opts={[3,4,5,6,7,8].map(n=>({v:String(n),l:`${n}h`}))}/></Lbl></div></div>
    <Lbl label="Couleur"><div style={{display:"flex",gap:"7px",flexWrap:"wrap"}}>{COLORS.map(c=><button key={c} onClick={()=>setColor(c)} style={{width:"30px",height:"30px",borderRadius:"7px",background:c,border:color===c?"3px solid #fff":"3px solid transparent",cursor:"pointer"}}/>)}</div></Lbl>
    <button style={{...S.or,width:"100%",marginTop:"6px"}} onClick={()=>{if(!f.name.trim())return;onAdd({id:Date.now(),name:f.name.trim(),model:f.model,owner:f.owner,color,s:f.s,e:f.e,dep:f.dep,hpd:Number(f.hpd),sh:f.sh,annots:[],docs:[],arts:[],sched:{},qc:{}});onClose();}}>Créer le bateau</button>
  </Sheet>;
}

// ── APP ───────────────────────────────────────────
export default function App(){
  const [boats,setBoats]=useState(DEMO_BOATS);
  const [view,setView]=useState("gantt");
  const [boatPage,setBoatPage]=useState(null);
  const [newBoat,setNewBoat]=useState(false);
  const [n,show]=useNotif();

  if(boatPage){const live=boats.find(b=>b.id===boatPage.id)||boatPage;return <><BoatPage boat={live} boats={boats} setBoats={setBoats} back={()=>setBoatPage(null)} show={show}/><Notif n={n}/></>;}

  const NAV=[{id:"gantt",l:"Gantt"},{id:"week",l:"Semaine"},{id:"day",l:"Journée"},{id:"qc",l:"Qualité"},{id:"import",l:"Import"}];
  return <div style={S.root}>
    <div style={S.hdr}>
      <span style={{fontSize:"20px"}}>⚓</span>
      <div style={{flex:1}}><div style={{fontSize:"14px",fontWeight:"800",letterSpacing:"1px"}}>YACHT SOLUTIONS</div><div style={{fontSize:"10px",color:"#4A5568",letterSpacing:"0.5px"}}>GESTION ATELIER</div></div>
      <div style={{background:"#F4821E22",color:"#F4821E",padding:"3px 9px",borderRadius:"20px",fontSize:"12px",fontWeight:"600"}}>{boats.length} bateaux</div>
    </div>
    <nav style={{display:"flex",background:"#0A1520",borderBottom:"1px solid #1A2D42",position:"sticky",top:"52px",zIndex:9}}>
      {NAV.map(t=><button key={t.id} onClick={()=>setView(t.id)} style={{flex:1,padding:"8px 0",background:"transparent",border:"none",borderBottom:view===t.id?"2px solid #F4821E":"2px solid transparent",color:view===t.id?"#F4821E":"#718096",cursor:"pointer",fontSize:"11px",fontWeight:view===t.id?"700":"400",fontFamily:"inherit"}}>{t.l}</button>)}
    </nav>
    <main style={{flex:1,overflowY:"auto"}}>
      {view==="gantt"&&<Gantt boats={boats} onBoat={setBoatPage} addBoat={()=>setNewBoat(true)}/>}
      {view==="week"&&<Week boats={boats}/>}
      {view==="day"&&<Day boats={boats}/>}
      {view==="qc"&&<QC boats={boats} setBoats={setBoats}/>}
      {view==="import"&&<Import boats={boats} setBoats={setBoats} show={show}/>}
    </main>
    <FAB onBoat={()=>setNewBoat(true)} onImport={()=>setView("import")}/>
    {newBoat&&<NewBoat onClose={()=>setNewBoat(false)} onAdd={b=>{setBoats(p=>[...p,b]);show("⛵ Bateau créé !");setBoatPage(b);}}/>}
    <Notif n={n}/>
  </div>;
}
