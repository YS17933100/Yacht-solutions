# Yacht Solutions — Gestion Atelier

Application mobile de gestion d'atelier pour Yacht Solutions.

## Fonctionnalités
- Gantt mensuel par bateau
- Planning semaine et journée par technicien
- Contrôle qualité (QC) par article
- Import CSV/Excel
- Validation par photo
- Export PDF planning semaine
- Micro-tâches avec photo

## Déploiement Vercel
1. Connectez ce repo à Vercel
2. Framework : Create React App
3. Deploy — c'est tout !
